# Trial Chamber Finder & Trident Tracker (Fabric, MC 1.21.11, reine Client-Mod)

## Bauen mit GitHub (ohne lokale Installation)
1. Auf github.com ein neues Repository anlegen.
2. Den Inhalt dieses Ordners hochladen (Add file -> Upload files; der Ordner `.github` muss mit).
3. Reiter **Actions** -> Workflow **build** -> den neuesten Lauf oeffnen.
4. Unten bei **Artifacts** `tcfinder-mod` herunterladen. Darin liegt `tcfinder-1.0.0.jar` (die Datei OHNE `-sources`).
5. Schlaegt der Build fehl: Log kopieren und mir schicken.

## Installieren
1. Fabric Loader 0.18.4+ fuer Minecraft 1.21.11 installieren und Fabric API 0.141.x fuer 1.21.11 in den `mods`-Ordner legen.
2. `tcfinder-1.0.0.jar` ebenfalls in `.minecraft/mods`.

## Benutzen / Testen
- Menue: Standardtaste **Rechts-Shift** (frei belegbar unter Steuerung).
- Tab *Finder*: Seed eingeben, **Suchen**. Du musst in der Oberwelt sein.
- Waypoint, HUD und Tracer werden in den Tabs eingestellt; alles wird in `config/tcfinder.json` gespeichert.
- Test: auf einem Server, dessen Seed du kennst, die berechnete Position mit Chunkbase vergleichen.

## Grenzen
- Positionen sind berechnet (Startposition der Struktur; Java 1.21: Abstand 34, Mindestabstand 12), Y ist geschaetzt.
- Truheninhalt kennt der Client erst nach dem Oeffnen. Davor: gelb (unbekannt).
- Grau markiert Chamber-Bereiche in nicht geladenen Chunks.
- Tracer sind 2D-Overlay-Linien (Bildschirmmitte unten zur Truhe), keine 3D-Linien in der Welt.
