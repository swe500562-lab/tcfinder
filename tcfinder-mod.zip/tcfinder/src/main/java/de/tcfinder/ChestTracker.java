package de.tcfinder;

import de.tcfinder.StructureFinder.Chamber;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.DoubleBlockProperties;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.*;

/**
 * Merkt sich Truhen in der Naehe berechneter Chambers und ihren Status.
 * GREEN  = Trident im geoeffneten Inhalt gesehen
 * RED    = Inhalt gesehen, kein Trident
 * YELLOW = Truhe bekannt (geladen), Inhalt unbekannt (der Server sendet ihn erst beim Oeffnen)
 * GRAY   = Chamber-Bereich liegt in nicht geladenen Chunks (wird im HUD als Gebiet markiert)
 * Es werden ausschliesslich Daten verwendet, die der Client ohnehin erhaelt.
 */
public final class ChestTracker {
    public enum State { GREEN, RED, YELLOW, GRAY }

    public static final Map<BlockPos, State> chests = new HashMap<>();
    public static BlockPos lastUsed = null;
    private static int openTicks = 0;
    private static int scanCounter = 0;
    private static final int NEAR = 96;

    public static boolean nearChamber(int x, int z) {
        for (Chamber c : TcState.chambers) {
            if (Math.abs(c.x() - x) <= NEAR && Math.abs(c.z() - z) <= NEAR) return true;
        }
        return false;
    }

    public static int count(State s) {
        int n = 0;
        for (State v : chests.values()) if (v == s) n++;
        return n;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) {
            chests.clear();
            lastUsed = null;
            return;
        }
        if (TcState.chambers.isEmpty() || !TcState.inOverworld(mc)) return;

        // 1) Geladene Truhen in der Naehe von Chambers erfassen (alle 2 Sekunden)
        if (++scanCounter % 40 == 0) {
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
            int r = 8;
            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    if (!nearChamber(cx * 16 + 8, cz * 16 + 8)) continue;
                    Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (ch == null) continue;
                    for (BlockPos p : ch.getBlockEntityPositions()) {
                        if (p.getY() > 20) continue;
                        BlockEntity be = mc.world.getBlockEntity(p);
                        if (be instanceof ChestBlockEntity) {
                            chests.putIfAbsent(p.toImmutable(), State.YELLOW);
                        }
                    }
                }
            }
        }

        // 2) Geoeffnete Truhe auswerten
        if (mc.currentScreen instanceof GenericContainerScreen gs && lastUsed != null) {
            openTicks++;
            if (openTicks >= 8) { // kurz warten, bis der Server den Inhalt gesendet hat
                GenericContainerScreenHandler h = gs.getScreenHandler();
                int n = h.getRows() * 9;
                boolean trident = false;
                for (int i = 0; i < n; i++) {
                    ItemStack s = h.getSlot(i).getStack();
                    if (s.isOf(Items.TRIDENT)) trident = true;
                }
                State st = trident ? State.GREEN : State.RED;
                if (nearChamber(lastUsed.getX(), lastUsed.getZ())) {
                    chests.put(lastUsed, st);
                    BlockPos other = otherHalf(mc, lastUsed);
                    if (other != null) chests.put(other, st);
                }
            }
        } else {
            openTicks = 0;
        }
    }

    private static BlockPos otherHalf(MinecraftClient mc, BlockPos p) {
        try {
            BlockState st = mc.world.getBlockState(p);
            if (st.getBlock() instanceof ChestBlock
                    && ChestBlock.getDoubleBlockType(st) != DoubleBlockProperties.Type.SINGLE) {
                return p.offset(ChestBlock.getFacing(st)).toImmutable();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public static List<Map.Entry<BlockPos, State>> sorted(MinecraftClient mc) {
        List<Map.Entry<BlockPos, State>> l = new ArrayList<>(chests.entrySet());
        if (mc.player != null) {
            l.sort(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(
                    e.getKey().getX() + .5, e.getKey().getY() + .5, e.getKey().getZ() + .5)));
        }
        return l;
    }

    private ChestTracker() {}
}
