package de.tcfinder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Dauerhaft gespeicherte Einstellungen (config/tcfinder.json). */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("tcfinder.json");

    public String seed = "";
    public boolean hud = true;
    public boolean autoWaypoint = true;
    public boolean autoSearch = true;
    public boolean autoNext = true;
    public boolean arrow = true;
    public boolean tracer = true;
    public boolean throughWalls = true;
    public boolean showGreen = true, showRed = false, showYellow = true, showGray = false;
    public int tracerRange = 256;
    public int searchRadius = 4000;
    public int hudX = 6, hudY = 6;
    public int colGreen = 0xFF55FF55, colRed = 0xFFFF5555, colYellow = 0xFFFFFF55, colGray = 0xFFAAAAAA;
    public boolean manualActive = false;
    public int manualX = 0, manualZ = 0;

    public static Config load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) return c;
            }
        } catch (Exception e) {
            System.err.println("[tcfinder] Config konnte nicht gelesen werden: " + e);
        }
        return new Config();
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(TcState.cfg));
        } catch (Exception e) {
            System.err.println("[tcfinder] Config konnte nicht gespeichert werden: " + e);
        }
    }
}
