package de.tcfinder;

import de.tcfinder.ChestTracker.State;
import de.tcfinder.StructureFinder.Chamber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** HUD, Waypoint-Pfeil und Tracer. Alles wird als 2D-Overlay gezeichnet und ist damit automatisch "durch Waende". */
public final class Hud {
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        Config cfg = TcState.cfg;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        if (TcState.inOverworld(mc)) {
            if (cfg.tracer) drawTracers(ctx, mc, w, h);
            drawWaypointMarker(ctx, mc, w, h);
        }
        if (cfg.hud) drawPanel(ctx, mc);
    }

    private static void drawPanel(DrawContext ctx, MinecraftClient mc) {
        Config cfg = TcState.cfg;
        List<String> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        lines.add("Trial Chamber Tool");
        colors.add(0xFFFFFFFF);

        String conn;
        if (mc.getCurrentServerEntry() != null) conn = "Server " + mc.getCurrentServerEntry().address;
        else if (mc.isInSingleplayer()) conn = "Einzelspieler";
        else conn = "keine Verbindung";
        lines.add("Verbindung: " + conn);
        colors.add(0xFFAAAAAA);

        if (!TcState.inOverworld(mc)) {
            lines.add("Nur in der Oberwelt aktiv");
            colors.add(0xFFFFAA00);
        } else if (cfg.seed == null || cfg.seed.isBlank()) {
            lines.add("Keine Seed: Menue oeffnen");
            colors.add(0xFFFFAA00);
        } else {
            Chamber t = TcState.target;
            if (t == null) {
                lines.add(TcState.chambers.isEmpty() ? "Keine Chamber im Suchradius" : "Kein Ziel aktiv");
                colors.add(0xFFFFAA00);
            } else {
                double d = TcState.horizDist(t, mc.player.getX(), mc.player.getZ());
                lines.add((TcState.targetIsManual ? "Ziel (manuell): " : "Naechste Chamber: ")
                        + t.x() + " ~" + StructureFinder.EST_Y + " " + t.z());
                colors.add(0xFF55FFFF);
                lines.add("Entfernung: " + Math.round(d) + " m");
                colors.add(0xFFFFFFFF);
                double dy = StructureFinder.EST_Y - mc.player.getY();
                String vert = Math.abs(dy) < 4 ? "auf gleicher Hoehe"
                        : Math.round(Math.abs(dy)) + " m " + (dy > 0 ? "oberhalb" : "unterhalb");
                lines.add((cfg.arrow ? arrowFor(mc, t) + "  " : "") + "Ziel-Y ca. " + vert);
                colors.add(0xFFFFFFFF);
            }
        }
        lines.add("Chambers: " + TcState.chambers.size() + "  |  Trident bestaetigt: " + ChestTracker.count(State.GREEN));
        colors.add(0xFFFFFFFF);
        lines.add("Auto-Waypoint: " + (cfg.autoWaypoint ? "AN" : "AUS") + "  Auto-Weiter: " + (cfg.autoNext ? "AN" : "AUS"));
        colors.add(0xFFAAAAAA);

        int width = 0;
        for (String s : lines) width = Math.max(width, mc.textRenderer.getWidth(s));
        int x = cfg.hudX, y = cfg.hudY;
        ctx.fill(x - 3, y - 3, x + width + 3, y + lines.size() * 11 + 1, 0x90000000);
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawTextWithShadow(mc.textRenderer, lines.get(i), x, y + i * 11, colors.get(i));
        }
    }

    private static String arrowFor(MinecraftClient mc, Chamber t) {
        double dx = t.x() - mc.player.getX(), dz = t.z() - mc.player.getZ();
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        int idx = Math.floorMod((int) Math.round(rel / 45.0), 8);
        return ARROWS[idx];
    }

    private static void drawWaypointMarker(DrawContext ctx, MinecraftClient mc, int w, int h) {
        Chamber t = TcState.target;
        if (t == null) return;
        Vec3d pos = new Vec3d(t.x() + 0.5, mc.player.getEyeY(), t.z() + 0.5);
        int[] p = project(mc, pos, w, h);
        double d = TcState.horizDist(t, mc.player.getX(), mc.player.getZ());
        ctx.fill(p[0] - 4, p[1] - 4, p[0] + 4, p[1] + 4, 0xFF55FFFF);
        String s = Math.round(d) + " m";
        ctx.drawTextWithShadow(mc.textRenderer, s, p[0] - mc.textRenderer.getWidth(s) / 2, p[1] + 7, 0xFF55FFFF);
    }

    private static void drawTracers(DrawContext ctx, MinecraftClient mc, int w, int h) {
        Config cfg = TcState.cfg;
        Vec3d eye = mc.player.getEyePos();
        for (Map.Entry<BlockPos, State> e : ChestTracker.chests.entrySet()) {
            State st = e.getValue();
            if (!enabled(cfg, st)) continue;
            BlockPos bp = e.getKey();
            Vec3d t = new Vec3d(bp.getX() + .5, bp.getY() + .5, bp.getZ() + .5);
            double dist = eye.distanceTo(t);
            if (dist > cfg.tracerRange) continue;
            if (!cfg.throughWalls && !visible(mc, eye, t)) continue;
            int color = colorOf(cfg, st);
            int[] p = project(mc, t, w, h);
            line(ctx, w / 2, h - 2, p[0], p[1], color);
            ctx.fill(p[0] - 3, p[1] - 3, p[0] + 3, p[1] + 3, color);
            String s = Math.round(dist) + " m";
            ctx.drawTextWithShadow(mc.textRenderer, s, p[0] + 6, p[1] - 4, color);
        }
        // GRAY: Chamber-Bereiche, deren Chunks noch nicht geladen sind (Truhen dort unbekannt)
        if (cfg.showGray) {
            for (Chamber c : TcState.nearestList(mc, 5)) {
                if (mc.world.getChunkManager().isChunkLoaded(c.x() >> 4, c.z() >> 4)) continue;
                Vec3d t = new Vec3d(c.x() + .5, StructureFinder.EST_Y, c.z() + .5);
                double dist = eye.distanceTo(t);
                if (dist > cfg.tracerRange) continue;
                int[] p = project(mc, t, w, h);
                line(ctx, w / 2, h - 2, p[0], p[1], cfg.colGray);
                ctx.drawTextWithShadow(mc.textRenderer, "nicht geladen " + Math.round(dist) + " m", p[0] + 6, p[1] - 4, cfg.colGray);
            }
        }
    }

    public static boolean enabled(Config c, State s) {
        return switch (s) {
            case GREEN -> c.showGreen;
            case RED -> c.showRed;
            case YELLOW -> c.showYellow;
            case GRAY -> c.showGray;
        };
    }

    public static int colorOf(Config c, State s) {
        return switch (s) {
            case GREEN -> c.colGreen;
            case RED -> c.colRed;
            case YELLOW -> c.colYellow;
            case GRAY -> c.colGray;
        };
    }

    private static boolean visible(MinecraftClient mc, Vec3d eye, Vec3d t) {
        var hit = mc.world.raycast(new RaycastContext(eye, t, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS;
    }

    /** Projiziert einen Weltpunkt auf den Bildschirm. Liegt er hinter dir, wird er an den Rand geklemmt. */
    public static int[] project(MinecraftClient mc, Vec3d target, int w, int h) {
        Vec3d d = target.subtract(mc.player.getEyePos());
        double yaw = Math.toRadians(mc.player.getYaw());
        double pitch = Math.toRadians(mc.player.getPitch());
        Vec3d f = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d r = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d u = new Vec3d(-Math.sin(yaw) * Math.sin(pitch), Math.cos(pitch), Math.cos(yaw) * Math.sin(pitch));
        double fw = d.dotProduct(f), rr = d.dotProduct(r), uu = d.dotProduct(u);
        double fovY = Math.toRadians(mc.options.getFov().getValue());
        double scale = (h / 2.0) / Math.tan(fovY / 2.0);
        double sx, sy;
        if (fw > 0.05) {
            sx = w / 2.0 + rr / fw * scale;
            sy = h / 2.0 - uu / fw * scale;
        } else {
            double len = Math.max(0.0001, Math.sqrt(rr * rr + uu * uu));
            sx = w / 2.0 + rr / len * w;
            sy = h / 2.0 - uu / len * w;
        }
        int x = MathHelper.clamp((int) sx, 8, w - 8);
        int y = MathHelper.clamp((int) sy, 8, h - 8);
        return new int[]{x, y};
    }

    public static void line(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        int dx = x2 - x1, dy = y2 - y1;
        int steps = Math.max(Math.abs(dx), Math.abs(dy));
        if (steps == 0) return;
        for (int i = 0; i <= steps; i += 2) {
            int x = x1 + dx * i / steps;
            int y = y1 + dy * i / steps;
            c.fill(x, y, x + 2, y + 2, color);
        }
    }

    private Hud() {}
}
