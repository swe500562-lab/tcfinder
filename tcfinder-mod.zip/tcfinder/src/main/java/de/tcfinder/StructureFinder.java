package de.tcfinder;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Berechnet die Positionen von Trial Chambers aus der Seed.
 * Nutzt die Random-Spread-Platzierung von Minecraft 1.21 (Abstand 32 Chunks, Mindestabstand 8, Salt 94251327).
 * Hinweis: Das ist die theoretische Startposition. Ob Biom/Gelaende dort wirklich eine Chamber zulassen,
 * wird nicht geprueft. Y ist nur eine Schaetzung.
 */
public final class StructureFinder {
    public static final int SPACING = 32;
    public static final int SEPARATION = 8;
    public static final long SALT = 94251327L;
    public static final int EST_Y = -28;

    public record Chamber(int x, int z) {
        public long key() {
            return ((long) x << 32) ^ (z & 0xffffffffL);
        }
    }

    public static long parseSeed(String s) {
        s = s.trim();
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return s.hashCode(); // wie Minecraft bei Text-Seeds
        }
    }

    public static List<Chamber> find(long seed, int cx, int cz, int radius) {
        List<Chamber> out = new ArrayList<>();
        int regionBlocks = SPACING * 16;
        int minRx = Math.floorDiv(cx - radius, regionBlocks) - 1;
        int maxRx = Math.floorDiv(cx + radius, regionBlocks) + 1;
        int minRz = Math.floorDiv(cz - radius, regionBlocks) - 1;
        int maxRz = Math.floorDiv(cz + radius, regionBlocks) + 1;
        for (int rx = minRx; rx <= maxRx; rx++) {
            for (int rz = minRz; rz <= maxRz; rz++) {
                long s = rx * 341873128712L + rz * 132897987541L + seed + SALT;
                Random r = new Random(s);
                int ox = r.nextInt(SPACING - SEPARATION);
                int oz = r.nextInt(SPACING - SEPARATION);
                int chunkX = rx * SPACING + ox;
                int chunkZ = rz * SPACING + oz;
                int bx = chunkX * 16 + 8;
                int bz = chunkZ * 16 + 8;
                long dx = bx - cx, dz = bz - cz;
                if (dx * dx + dz * dz <= (long) radius * radius) {
                    out.add(new Chamber(bx, bz));
                }
            }
        }
        return out;
    }

    private StructureFinder() {}
}
