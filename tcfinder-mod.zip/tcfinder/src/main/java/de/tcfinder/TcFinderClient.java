package de.tcfinder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.ChestBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class TcFinderClient implements ClientModInitializer {
    public static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        TcState.cfg = Config.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("tcfinder", "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.tcfinder.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                mc.setScreen(new TcScreen());
            }
            TcState.tick(mc);
        });

        HudRenderCallback.EVENT.register(Hud::render);

        // Merkt sich, welche Truhe du anklickst (nur lokal, es wird nichts veraendert oder gesendet)
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient() && world.getBlockState(hit.getBlockPos()).getBlock() instanceof ChestBlock) {
                ChestTracker.lastUsed = hit.getBlockPos().toImmutable();
            }
            return ActionResult.PASS;
        });
    }
}
