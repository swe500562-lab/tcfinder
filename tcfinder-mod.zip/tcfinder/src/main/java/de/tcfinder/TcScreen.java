package de.tcfinder;

import de.tcfinder.ChestTracker.State;
import de.tcfinder.StructureFinder.Chamber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class TcScreen extends Screen {
    private static int tab = 0;
    private static final int[] PRESETS = {0xFF55FF55, 0xFFFF5555, 0xFFFFFF55, 0xFFAAAAAA, 0xFF55FFFF, 0xFFFF55FF, 0xFFFFFFFF, 0xFFFFAA00};
    private static final String[] PNAMES = {"Gruen", "Rot", "Gelb", "Grau", "Cyan", "Magenta", "Weiss", "Orange"};

    private TextFieldWidget seedField;

    public TcScreen() {
        super(Text.literal("Trial Chamber Tool"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        if (seedField != null) TcState.cfg.seed = seedField.getText();
        Config.save();
    }

    @Override
    protected void init() {
        int left = width / 2 - 150;
        String[] names = {"Finder", "Waypoint", "Trident", "Tracer", "HUD"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(Text.literal((tab == i ? "> " : "") + names[i]), b -> {
                if (seedField != null) TcState.cfg.seed = seedField.getText();
                tab = idx;
                clearAndInit();
            }).dimensions(left + i * 61, 8, 58, 18).build());
        }
        seedField = null;
        int y = 36;
        switch (tab) {
            case 0 -> initFinder(left, y);
            case 1 -> initWaypoint(left, y);
            case 2 -> initTrident(left, y);
            case 3 -> initTracer(left, y);
            default -> initHud(left, y);
        }
    }

    private void initFinder(int left, int y) {
        Config c = TcState.cfg;
        MinecraftClient mc = MinecraftClient.getInstance();
        seedField = new TextFieldWidget(textRenderer, left, y, 200, 20, Text.literal("Seed"));
        seedField.setMaxLength(64);
        seedField.setText(c.seed == null ? "" : c.seed);
        addDrawableChild(seedField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Suchen"), b -> {
            c.seed = seedField.getText();
            Config.save();
            TcState.search(mc);
            clearAndInit();
        }).dimensions(left + 205, y, 95, 20).build());
        y += 26;
        if (mc.player != null) {
            List<Chamber> near = TcState.nearestList(mc, 6);
            for (Chamber ch : near) {
                double d = TcState.horizDist(ch, mc.player.getX(), mc.player.getZ());
                String label = String.format("X %d   Y ca. %d   Z %d   -   %d m", ch.x(), StructureFinder.EST_Y, ch.z(), Math.round(d));
                addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                    c.manualActive = true;
                    c.manualX = ch.x();
                    c.manualZ = ch.z();
                    Config.save();
                }).dimensions(left, y, 300, 20).build());
                y += 22;
            }
        }
        y += 4;
        addDrawableChild(ButtonWidget.builder(Text.literal("Mehr suchen (+2000)"), b -> {
            c.searchRadius = Math.min(c.searchRadius + 2000, 30000);
            TcState.search(mc);
            clearAndInit();
        }).dimensions(left, y, 148, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Manuelles Ziel aus"), b -> {
            c.manualActive = false;
            Config.save();
        }).dimensions(left + 152, y, 148, 20).build());
    }

    private void initWaypoint(int left, int y) {
        Config c = TcState.cfg;
        toggle(left, y, "Auto-Waypoint (naechste Chamber)", () -> c.autoWaypoint, v -> c.autoWaypoint = v);
        toggle(left, y + 22, "Richtungspfeil", () -> c.arrow, v -> c.arrow = v);
        toggle(left, y + 44, "Automatisch zum naechsten Ziel", () -> c.autoNext, v -> c.autoNext = v);
        toggle(left, y + 66, "Automatische Suche", () -> c.autoSearch, v -> c.autoSearch = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Besuchte Chambers zuruecksetzen"), b -> TcState.visited.clear())
                .dimensions(left, y + 88, 300, 20).build());
    }

    private void initTrident(int left, int y) {
        Config c = TcState.cfg;
        toggle(left, y, "Gruen (Trident gefunden) anzeigen", () -> c.showGreen, v -> c.showGreen = v);
        toggle(left, y + 22, "Gelb (Inhalt unbekannt) anzeigen", () -> c.showYellow, v -> c.showYellow = v);
        toggle(left, y + 44, "Rot (kein Trident) anzeigen", () -> c.showRed, v -> c.showRed = v);
        toggle(left, y + 66, "Grau (nicht geladen) anzeigen", () -> c.showGray, v -> c.showGray = v);
    }

    private void initTracer(int left, int y) {
        Config c = TcState.cfg;
        toggle(left, y, "Tracer", () -> c.tracer, v -> c.tracer = v);
        toggle(left, y + 22, "Durch Waende anzeigen", () -> c.throughWalls, v -> c.throughWalls = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            c.tracerRange = Math.max(32, c.tracerRange - 32);
            clearAndInit();
        }).dimensions(left, y + 44, 40, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            c.tracerRange = Math.min(1024, c.tracerRange + 32);
            clearAndInit();
        }).dimensions(left + 260, y + 44, 40, 20).build());
        colorButton(left, y + 66, "Gruen", () -> c.colGreen, v -> c.colGreen = v);
        colorButton(left, y + 88, "Gelb", () -> c.colYellow, v -> c.colYellow = v);
        colorButton(left, y + 110, "Rot", () -> c.colRed, v -> c.colRed = v);
        colorButton(left, y + 132, "Grau", () -> c.colGray, v -> c.colGray = v);
    }

    private void initHud(int left, int y) {
        Config c = TcState.cfg;
        toggle(left, y, "HUD anzeigen", () -> c.hud, v -> c.hud = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD links"), b -> c.hudX = Math.max(0, c.hudX - 10)).dimensions(left, y + 26, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD rechts"), b -> c.hudX = Math.min(width - 40, c.hudX + 10)).dimensions(left + 101, y + 26, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD hoch"), b -> c.hudY = Math.max(0, c.hudY - 10)).dimensions(left, y + 48, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD runter"), b -> c.hudY = Math.min(height - 20, c.hudY + 10)).dimensions(left + 101, y + 48, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Position zuruecksetzen"), b -> {
            c.hudX = 6;
            c.hudY = 6;
        }).dimensions(left + 202, y + 26, 98, 42).build());
    }

    private void toggle(int x, int y, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label + ": " + (get.get() ? "AN" : "AUS")), b -> {
            set.accept(!get.get());
            Config.save();
            b.setMessage(Text.literal(label + ": " + (get.get() ? "AN" : "AUS")));
        }).dimensions(x, y, 300, 20).build());
    }

    private void colorButton(int x, int y, String label, Supplier<Integer> get, Consumer<Integer> set) {
        addDrawableChild(ButtonWidget.builder(Text.literal("Farbe " + label + ": " + colorName(get.get())), b -> {
            int idx = 0;
            for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == get.get()) idx = i;
            set.accept(PRESETS[(idx + 1) % PRESETS.length]);
            Config.save();
            b.setMessage(Text.literal("Farbe " + label + ": " + colorName(get.get())));
        }).dimensions(x, y, 300, 20).build());
    }

    private static String colorName(int col) {
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == col) return PNAMES[i];
        return "Eigene";
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = TcState.cfg;
        int left = width / 2 - 150;
        int y0 = 36;
        switch (tab) {
            case 0 -> {
                int yy = y0 + 26 + 22 * Math.min(6, TcState.nearestList(mc, 6).size()) + 30;
                ctx.drawTextWithShadow(textRenderer, "Gefunden: " + TcState.chambers.size() + "  (Radius " + c.searchRadius + " Bloecke)", left, yy, 0xFFFFFFFF);
                ctx.drawTextWithShadow(textRenderer, "Klick auf eine Chamber = manuelles Ziel", left, yy + 11, 0xFFAAAAAA);
                ctx.drawTextWithShadow(textRenderer, "Berechnete Position, Y ist geschaetzt. Seed muss zum Server passen.", left, yy + 22, 0xFFAAAAAA);
                if (!TcState.inOverworld(mc)) ctx.drawTextWithShadow(textRenderer, "Achtung: Du bist nicht in der Oberwelt.", left, yy + 33, 0xFFFFAA00);
            }
            case 1 -> {
                Chamber t = TcState.target;
                int yy = y0 + 118;
                if (t != null && mc.player != null) {
                    ctx.drawTextWithShadow(textRenderer, "Aktuelles Ziel: " + t.x() + " ~" + StructureFinder.EST_Y + " " + t.z()
                            + "  (" + Math.round(TcState.horizDist(t, mc.player.getX(), mc.player.getZ())) + " m)", left, yy, 0xFF55FFFF);
                } else {
                    ctx.drawTextWithShadow(textRenderer, "Aktuelles Ziel: keins", left, yy, 0xFFAAAAAA);
                }
            }
            case 2 -> {
                int yy = y0 + 92;
                ctx.drawTextWithShadow(textRenderer, "Bestaetigt: " + ChestTracker.count(State.GREEN) + "   Leer/kein Trident: " + ChestTracker.count(State.RED)
                        + "   Unbekannt: " + ChestTracker.count(State.YELLOW), left, yy, 0xFFFFFFFF);
                yy += 12;
                ctx.drawTextWithShadow(textRenderer, "Inhalt ist nur bekannt, nachdem du die Truhe geoeffnet hast.", left, yy, 0xFFAAAAAA);
                yy += 14;
                List<Map.Entry<BlockPos, State>> list = ChestTracker.sorted(mc);
                int n = 0;
                for (Map.Entry<BlockPos, State> e : list) {
                    if (n++ >= 8 || mc.player == null) break;
                    BlockPos p = e.getKey();
                    double d = Math.sqrt(mc.player.squaredDistanceTo(p.getX() + .5, p.getY() + .5, p.getZ() + .5));
                    String s = p.getX() + " " + p.getY() + " " + p.getZ() + "  -  " + Math.round(d) + " m  -  " + label(e.getValue());
                    ctx.drawTextWithShadow(textRenderer, s, left, yy, Hud.colorOf(c, e.getValue()));
                    yy += 11;
                }
            }
            case 3 -> ctx.drawCenteredTextWithShadow(textRenderer, "Reichweite: " + c.tracerRange + " m", width / 2, y0 + 50, 0xFFFFFFFF);
            default -> {
            }
        }
    }

    private static String label(State s) {
        return switch (s) {
            case GREEN -> "TRIDENT GEFUNDEN";
            case RED -> "kein Trident";
            case YELLOW -> "Inhalt unbekannt";
            case GRAY -> "nicht geladen";
        };
    }
}
