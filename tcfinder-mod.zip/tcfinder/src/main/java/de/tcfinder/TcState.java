package de.tcfinder;

import de.tcfinder.StructureFinder.Chamber;
import net.minecraft.client.MinecraftClient;
import net.minecraft.world.World;

import java.util.*;

/** Gemeinsamer Zustand: Chambers, Ziel, besuchte Chambers. Alles laeuft im Client-Thread. */
public final class TcState {
    public static Config cfg = new Config();
    public static List<Chamber> chambers = new ArrayList<>();
    public static final Set<Long> visited = new HashSet<>();
    public static Chamber target = null;
    public static boolean targetIsManual = false;
    private static int lastX, lastZ;
    private static String lastSeed = null;
    private static int tickCounter = 0;

    public static boolean inOverworld(MinecraftClient mc) {
        return mc.world != null && mc.world.getRegistryKey() == World.OVERWORLD;
    }

    public static void search(MinecraftClient mc) {
        if (mc.player == null) return;
        int px = mc.player.getBlockX(), pz = mc.player.getBlockZ();
        if (cfg.seed == null || cfg.seed.isBlank()) {
            chambers = new ArrayList<>();
        } else {
            chambers = StructureFinder.find(StructureFinder.parseSeed(cfg.seed), px, pz, cfg.searchRadius);
        }
        lastX = px;
        lastZ = pz;
        lastSeed = cfg.seed;
        visited.clear();
    }

    public static double horizDist(Chamber c, double px, double pz) {
        double dx = c.x() - px, dz = c.z() - pz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static List<Chamber> nearestList(MinecraftClient mc, int n) {
        if (mc.player == null) return List.of();
        double px = mc.player.getX(), pz = mc.player.getZ();
        List<Chamber> copy = new ArrayList<>(chambers);
        copy.sort(Comparator.comparingDouble(c -> horizDist(c, px, pz)));
        return copy.size() > n ? copy.subList(0, n) : copy;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        ChestTracker.tick(mc);

        if (!inOverworld(mc) || cfg.seed == null || cfg.seed.isBlank()) {
            target = null;
            return;
        }
        int px = mc.player.getBlockX(), pz = mc.player.getBlockZ();
        if (cfg.autoSearch) {
            long dx = px - lastX, dz = pz - lastZ;
            boolean moved = dx * dx + dz * dz > 1000L * 1000L;
            if (lastSeed == null || !lastSeed.equals(cfg.seed) || moved) search(mc);
        }

        if (++tickCounter % 10 != 0) return; // Ziel alle 10 Ticks aus der AKTUELLEN Position neu berechnen

        double x = mc.player.getX(), z = mc.player.getZ();
        if (cfg.manualActive) {
            target = new Chamber(cfg.manualX, cfg.manualZ);
            targetIsManual = true;
            return;
        }
        targetIsManual = false;
        if (!cfg.autoWaypoint) {
            target = null;
            return;
        }
        Chamber best = null;
        double bestD = Double.MAX_VALUE;
        for (Chamber c : chambers) {
            if (visited.contains(c.key())) continue;
            double d = horizDist(c, x, z);
            if (d < bestD) {
                bestD = d;
                best = c;
            }
        }
        target = best;
        if (best != null && bestD < 24 && cfg.autoNext) {
            visited.add(best.key()); // erreicht -> beim naechsten Durchlauf die naechste waehlen
        }
    }

    private TcState() {}
}
